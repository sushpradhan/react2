import React from 'react'



const ReadLater=()=>{
    return(
        <div>

        </div>
    )
}

export default  ReadLater;